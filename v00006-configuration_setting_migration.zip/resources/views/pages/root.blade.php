@extends('layouts.app')
@section('title', 'homepage')

@section('content')
  <h1>this is homepage</h1>
@stop