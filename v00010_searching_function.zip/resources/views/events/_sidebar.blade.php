<div class="card ">
  <div class="card-body">
    Right Navigation Bar
  </div>
</div>